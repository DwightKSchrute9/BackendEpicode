package com.SpringBoot_SpringSecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityExampleV2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
