package com.Capstone_BET.SpringBoot_SpringSecurity.entity;

public enum ERole {
	ROLE_USER,
    ROLE_ADMIN,
    ROLE_MODERATOR;
}
