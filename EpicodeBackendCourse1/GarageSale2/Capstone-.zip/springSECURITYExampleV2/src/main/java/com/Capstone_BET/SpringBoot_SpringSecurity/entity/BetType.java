package com.Capstone_BET.SpringBoot_SpringSecurity.entity;

public enum BetType {
	HOME,
	AWAY,
	DRAW
	// @TODO: ADD ALL TYPES//
}
