package com.Capstone_BET.SpringBoot_SpringSecurity.entity;

public enum BetStatus {
	ACCEPTED,
	PENDING,
	CANCELED
}
