package com.Capstone_BET.SpringBoot_SpringSecurity.main.entities;

public class Matches {

}
