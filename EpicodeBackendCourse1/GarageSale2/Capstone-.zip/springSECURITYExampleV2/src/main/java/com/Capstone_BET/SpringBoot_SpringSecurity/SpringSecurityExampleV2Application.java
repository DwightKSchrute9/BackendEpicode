package com.Capstone_BET.SpringBoot_SpringSecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityExampleV2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityExampleV2Application.class, args);
	}

}
