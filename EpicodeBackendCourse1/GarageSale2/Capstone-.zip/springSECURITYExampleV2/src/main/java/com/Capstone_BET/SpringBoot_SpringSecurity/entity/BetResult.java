package com.Capstone_BET.SpringBoot_SpringSecurity.entity;

public enum BetResult {
	WINNING,
	LOSING,
	PENDING
}
